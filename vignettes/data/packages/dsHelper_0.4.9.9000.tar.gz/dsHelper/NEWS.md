# dsHelper (development version)

# dsHelper 0.4.9

# dsHelper 0.4.8

# dsHelper 0.4.7

# dsHelper 0.4.6

# dsHelper 0.4.5

# dsHelper 0.4.4

# dsHelper 0.4.3

# dsHelper 0.4.2

# dsHelper 0.4.1

# dsHelper 0.3.1

# dsHelper 0.2.2

# dsHelper 0.2.1

# dsHelper 0.1.3

# dsHelper 0.1.2

# dsHelper 0.1.1

# dsHelper 0.0.1

# dsHelper 0.0.0.9008

* Added a `NEWS.md` file to track changes to the package.
