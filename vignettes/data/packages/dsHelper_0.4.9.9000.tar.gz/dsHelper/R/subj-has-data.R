#' This was an old version of dh.defineCases which is now defunct
#'
#' @export
dh.subjHasData <- function() {
  .Defunct("dh.defineCases")
}
