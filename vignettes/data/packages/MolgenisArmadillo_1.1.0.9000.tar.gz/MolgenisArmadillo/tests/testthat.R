library(testthat)
library(MolgenisArmadillo)

test_check("MolgenisArmadillo")
