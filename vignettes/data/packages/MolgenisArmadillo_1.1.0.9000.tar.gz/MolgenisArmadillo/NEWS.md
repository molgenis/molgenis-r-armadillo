# MolgenisArmadillo 1.0.3

# MolgenisArmadillo 1.0.2

# MolgenisArmadillo 1.0.1

* Do not use arrow in unit tests

# MolgenisArmadillo 1.0.0

* Release to CRAN
* Loaded objects no longer are put into the parent environment but
returned from their function instead.
